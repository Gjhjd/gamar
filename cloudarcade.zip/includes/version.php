<?php

define( "VERSION", "1.6.5" );

?>