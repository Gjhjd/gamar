<?php
/**
 * File: theme-functions.php
 * 
 * This script is used to define a collection of functions that are specifically designed 
 * for theme related functionality. This can include things like rendering HTML components,
 * handling pagination, or setting up multilingual support.
 * 
 * The functions defined in this file are designed to be used in various parts of the theme 
 * templates, offering a way to abstract common functionality and promote reusability.
 * 
 * Please note that this file may be updated frequently during CMS updates. 
 * It is recommended NOT to modify this file directly, as your changes may be 
 * overwritten during an update.
 */

function render_pagination($total_page, $cur_page = 1, $display_limit = 8, $pageType = 'category', $slug = '', $htmlOptions = []) {
	$defaults = [
		'container' => 'ul',
		'container_class' => 'pagination justify-content-center',
		'item' => 'li',
		'item_class' => 'page-item',
		'link' => 'a',
		'link_class' => 'page-link',
		'disabled_class' => 'disabled'
	];

	$htmlOptions = array_merge($defaults, $htmlOptions);
	
	$paginationHTML = "<{$htmlOptions['container']} class=\"{$htmlOptions['container_class']}\">";

	if($total_page) {
		$start = max(0, $cur_page - ceil($display_limit / 2));
		$end = min($start + $display_limit, $total_page);

		if ($start > 0) {
			$paginationHTML .= "<{$htmlOptions['item']} class=\"{$htmlOptions['item_class']}\"><{$htmlOptions['link']} class=\"{$htmlOptions['link_class']}\" href=\"". get_permalink($pageType, $slug) ."\">1</{$htmlOptions['link']}></{$htmlOptions['item']}>";
			$paginationHTML .= "<{$htmlOptions['item']} class=\"{$htmlOptions['item_class']} {$htmlOptions['disabled_class']}\"><span class=\"{$htmlOptions['link_class']}\">...</span></{$htmlOptions['item']}>";
		}

		for ($i = $start; $i < $end; $i++) {
			$disabled = $cur_page == ($i + 1) ? $htmlOptions['disabled_class'] : '';
			$page_number = $i + 1;
			$page_url = $page_number > 1 ? get_permalink($pageType, $slug, array('page' => $page_number)) : get_permalink($pageType, $slug);
			$paginationHTML .= "<{$htmlOptions['item']} class=\"{$htmlOptions['item_class']} {$disabled}\"><{$htmlOptions['link']} class=\"{$htmlOptions['link_class']}\" href=\"{$page_url}\">". ($page_number) ."</{$htmlOptions['link']}></{$htmlOptions['item']}>";
		}

		if ($end < $total_page) {
			$paginationHTML .= "<{$htmlOptions['item']} class=\"{$htmlOptions['item_class']} {$htmlOptions['disabled_class']}\"><span class=\"{$htmlOptions['link_class']}\">...</span></{$htmlOptions['item']}>";
			$paginationHTML .= "<{$htmlOptions['item']} class=\"{$htmlOptions['item_class']}\"><{$htmlOptions['link']} class=\"{$htmlOptions['link_class']}\" href=\"". get_permalink($pageType, $slug, array('page' => $total_page)) ."\">{$total_page}</{$htmlOptions['link']}></{$htmlOptions['item']}>";
		}
	}
	$paginationHTML .= "</{$htmlOptions['container']}>";
	echo $paginationHTML;
}

function the_html_attrs() {
	/*
	* This function is used to print HTML attributes inside the <html> tag for multilingual support 
	* and Right-to-Left (RTL) language handling. It considers the language code (ISO 639-1) for 
	* setting the "lang" attribute and also checks if the language is RTL to set the "dir" attribute.
	*/
	global $lang_code;
	// List of RTL language codes.
	$rtl_langs = ['ar', 'fa', 'ur', 'he', 'iw', 'yi', 'ku', 'ps', 'sd', 'ug', 'dv'];
	// Check if current language is RTL.
	$dir = in_array($lang_code, $rtl_langs) ? 'rtl' : 'ltr';
	if(get_setting_value('disable_rtl')){
		$dir = 'ltr';
	}
	// Print the lang and dir attributes.
	echo "lang=\"{$lang_code}\" dir=\"{$dir}\"";
}

function the_canonical_link() {
	global $url_params;
	global $base_taxonomy;
	$allowed_taxonomy = ['game', 'category', 'search', 'post', 'page', 'tag'];
	if(!PRETTY_URL || count($url_params) <= 1 || count($url_params) > 2) return;
	if(!in_array($base_taxonomy, $allowed_taxonomy)){
		return;
	}
	$canonical_url = get_permalink($url_params[0], $url_params[1]);
	echo "<link rel=\"canonical\" href=\"{$canonical_url}\" />".PHP_EOL;
}

function fetch_games_by_type($type, $amount=12, $page=0, $count=true){
	// Fetches a list of games based on different criteria: 'new', 'random', 'popular', 'likes', and 'trending'.
	$data = [];
	if ($type == 'trending') {
		$conn = open_connection();
		$date = new \DateTime('now');
		$date->sub(new DateInterval('P7D'));
		$sql = "SELECT * FROM trends WHERE created >= '{$date->format('Y-m-d')}'";
		$st = $conn->prepare($sql);
		$st->execute();
		$row = $st->fetchAll(PDO::FETCH_ASSOC);
		$list = array();
		if(count($row)){
			foreach ($row as $item) {
				if(isset($list[$item['slug']])){
					$list[$item['slug']] += (int)$item['views'];
				} else {
					$list[$item['slug']] = (int)$item['views'];
				}
			}
			arsort($list);
			$i = 0;
			foreach ($list as $slug => $views) {
				if($i < $amount){
					$game = Game::getBySlug($slug);
					if($game){
						$data[] = $game;
					}
				}
				$i++;
			}
		}
		return (array(
			"results" => $data,
			"totalRows" => count($list),
			"totalPages" => 1
		));
	} else {
		switch($type) {
			case 'new':
				$order_by = 'id DESC';
				break;
			case 'random':
				$order_by = 'RAND()';
				break;
			case 'popular':
				$order_by = 'views DESC';
				break;
			case 'likes':
				$order_by = 'upvote DESC';
				break;
			default:
				throw new InvalidArgumentException('Invalid type provided');
		}
		return Game::getList($amount, $order_by, $page, $count);
	}
}

function fetch_collection($name, $amount = 12){
	// Fetches a game collection based on a specified name.
	$data = Collection::getListByCollection( $name, $amount );
	return $data;
}

function fetch_games_by_category($cat_name, $amount, $page = 0) {
	// Fetches a list of games from a specific category.
	$cat_id = Category::getIdByName($cat_name);
	$data = Category::getListByCategory($cat_id, $amount, $page);
	return $data;
}

function fetch_similar_games($game, $amount, $page = 0, $random = true) {
	// This function is used to get the list of similar games based on current $game categories
	// Mostly used for single-game page "Similar Games" section
	$category_list = $game->getCategoryList(); // Excluding hidden categories
	$ids = array_map(function($category) {
		return $category['id'];
	}, $category_list);
	$data = Category::getListByCategories($ids, $amount, $page, $random);
	return $data;
}

function fetch_all_categories($show_hidden_category = false, $show_empty_category = false){
	// Get the list of all categories
	$data = Category::getList();
	$results = $data['results'];
	foreach ($results as $key => $category) {
		if(!$show_hidden_category && $category->priority < 0){
			unset($results[$key]);
			continue;
		}
		if(!$show_empty_category && Category::getCategoryCount($category->id) == 0){
			unset($results[$key]);
			continue;
		}
	}
	return $results;
}

function get_page_title($title_template = 'default'){
	// Check if the custom override function exists
	if (function_exists('get_custom_page_title')) {
		$custom_title = get_custom_page_title();
		if($custom_title != 'default'){
			return htmlspecialchars($custom_title);
		}
	}
	global $base_taxonomy;
	$content_title;
	switch($base_taxonomy){
		case 'game':
			global $game;
			$content_title = $game->title;
			break;
		case 'full':
			global $game;
			$content_title = $game->title;
			break;
		case 'splash':
			global $game;
			$content_title = $game->title;
			break;
		case 'category':
			global $category;
			$content_title = $category->name;
			break;
		case 'tag':
			global $tag_name;
			$content_title = $tag_name;
			break;
		case 'user':
			global $url_params;
			$content_title = $url_params[1];
			break;
		case 'page':
			global $page;
			$content_title = $page->title;
			break;
		case 'post':
			global $post;
			$content_title = $post->title;
			break;
		case '404':
			$content_title = '404';
			break;
		case 'search':
			$content_title = _t('Search %a Games', $_GET['slug']);
			break;
		default:
			$content_title = SITE_TITLE;
	}
	if($title_template == 'default'){
		if($base_taxonomy == 'user'){
			return htmlspecialchars($content_title);
		} else {
			return htmlspecialchars($content_title . ' | ' . SITE_DESCRIPTION);
		}
	} else {
		$title_template = str_replace('{content_title}', $content_title, $title_template);
		$title_template = str_replace('{site_description}', SITE_DESCRIPTION, $title_template);
		$title_template = str_replace('{site_title}', SITE_TITLE, $title_template);
		return htmlspecialchars($title_template);
	}
}

function get_current_user_data(){
	// Get current logged-in visitor data or info
	// return null if visitor is not logged-in user
	if(is_login()){
		global $login_user;
		return $login_user;
	} else {
		return null;
	}
}

function get_theme_header(){
	global $page_title;
	global $meta_description;
	global $login_user;
	if(file_exists(TEMPLATE_PATH . '/header.php')){
		include TEMPLATE_PATH . '/header.php';
	} else if(file_exists(TEMPLATE_PATH . '/includes/header.php')){
		include TEMPLATE_PATH . '/includes/header.php';
	}
}

function get_theme_sidebar(){
	global $page_title;
	global $meta_description;
	global $login_user;
	if(file_exists(TEMPLATE_PATH . '/sidebar.php')){
		include TEMPLATE_PATH . '/sidebar.php';
	} else if(file_exists(TEMPLATE_PATH . '/includes/sidebar.php')){
		include TEMPLATE_PATH . '/includes/sidebar.php';
	} else if(file_exists(TEMPLATE_PATH . '/parts/sidebar.php')){
		include TEMPLATE_PATH . '/parts/sidebar.php';
	}
}

function get_theme_footer(){
	global $page_title;
	global $meta_description;
	global $login_user;
	if(file_exists(TEMPLATE_PATH . '/footer.php')){
		include TEMPLATE_PATH . '/footer.php';
	} else if(file_exists(TEMPLATE_PATH . '/includes/footer.php')){
		include TEMPLATE_PATH . '/includes/footer.php';
	}
}

function can_show_leaderboard(){
	// Check if current $game can show leaderboard or not by checking game source
	// return true if current game is self-upload/hosted
	global $game;
	if(isset($game)){
		if($game->source == 'self'){
			return true;
		}
	}
	return false;
}

function render_game_comments($game_id){
	if(get_setting_value('comments')){
		if (function_exists('custom_render_game_comments')) {
			custom_render_game_comments($game_id);
			return;
		} else {
			?>
			<div id="tpl-comment-section" data-id="<?php echo esc_int($game_id) ?>">
				<?php if(is_login()){ ?>
				<div id="comment-form">
					<div class="comment-profile-avatar">
						<img src="<?php echo get_user_avatar() ?>">
					</div>
					<div class="comment-form-wrapper" id="tpl-comment-form">
						<div class="tpl-alert-tooshort" style="display: none;"><?php _e('Your comment is too short. Please enter at least {{min}} characters.') ?></div>
						<textarea class="form-control tpl-comment-input" rows="3" placeholder="Enter your comment here..."></textarea>
						<div class="post-comment-btn-wrapper">
							<button class="btn btn-primary tpl-post-comment-btn btn-sm"><?php _e('Post comment') ?></button>
						</div>
					</div>
				</div>
				<?php } else { ?>
					<div class="comment-require-login-wrapper">
						<div class="comment-profile-avatar">
							<img src="<?php echo DOMAIN . 'images/default_profile.png' ?>">
						</div>
						<div class="comment-alert">
							<?php _e('You must log in to write a comment.') ?>
						</div>
					</div>
				<?php } ?>
				<div id="tpl-comment-list">
				</div>
				<!-- Comment template -->
				<div id="tpl-comment-template" style="display:none;">
					<!-- User comment template -->
					<div class="tpl-user-comment" data-id="{{comment_id}}">
						<div class="user-comment-wrapper">
							<div class="user-comment-avatar">
								<img class="tpl-user-comment-avatar" src="{{profile_picture_url}}" alt="User Avatar">
							</div>
							<div class="comment-content">
								<div class="tpl-comment-author">{{fullname}}</div>
								<div class="tpl-comment-timestamp">{{created}}</div>
								<div class="tpl-comment-text">{{content}}</div>
								<div class="comment-actions">
									<div class="comment-action-left">
										<div class="reply-wrapper">
											<a href="#" onclick="return false;" class="tpl-btn-show-replies" data-id="{{comment_id}}"><i class="fa fa-comment-o" aria-hidden="true"></i> <?php _e('Show replies') ?></a>
											<a href="#" onclick="return false;" class="tpl-btn-hide-replies" data-id="{{comment_id}}"><i class="fa fa-comment-o" aria-hidden="true"></i> <?php _e('Hide replies') ?></a>
										</div>
									</div>
									<?php if(is_login()){ ?>
									<div class="comment-action-right">
										<a href="#" class="tpl-comment-reply" data-id="{{comment_id}}">
											<i class="fa fa-reply" aria-hidden="true"></i> Reply
										</a>
									</div>
									<?php } ?>
								</div>
							</div>
						</div>
						<div class="tpl-reply-form-wrapper"></div>
						<div class="tpl-comment-children"></div>
					</div>
					<!-- Reply form template -->
					<div class="tpl-reply-form">
						<div class="comment-reply-wrapper">
							<textarea class="form-control tpl-reply-input" placeholder="Your reply..."></textarea>
							<div class="reply-action-buttons">
								<button class="btn btn-sm tpl-btn-cancel-reply" data-id="{{comment_id}}"><?php _e('Cancel') ?></button>
								<button class="btn btn-primary btn-sm tpl-btn-send-reply" data-id="{{comment_id}}"><?php _e('Reply') ?></button>
							</div>
						</div>
					</div>
				</div>
				<div id="tpl-btn-load-more-comments" class="btn" style="display: none;"><?php _e('Load more comments') ?> <i class="fa fa-chevron-down" aria-hidden="true"></i></div>
			</div>
			<?php
		}
	}
}

?>